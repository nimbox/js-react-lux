export interface ReactionData {

    emoji: string;
    count: number;

}
