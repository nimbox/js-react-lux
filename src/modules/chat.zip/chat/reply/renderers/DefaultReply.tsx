export { TextReplyRenderer as DefaultReplyRenderer } from './TextReply';
