export { TextMessageRenderer as DefaultMessageRenderer } from './TextMessage';
